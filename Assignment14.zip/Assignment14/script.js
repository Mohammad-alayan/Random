function in_card(){
document.getElementById("outside").className="in-card"
}
function close_card(){
    document.getElementById("outside").className=""
}